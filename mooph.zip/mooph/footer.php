<div id="footer"> Proudly powered by <a href="http://www.wordpress.org">WordPress</a>&nbsp;&nbsp;|&nbsp;&nbsp;Copyright &copy; <?php echo date('Y'); ?> <a href="<?php bloginfo('url') ?>">
  <?php bloginfo('name'); ?>
  </a> all rights reserved.
  <?php /*Please do not remove the below lineshjose.com free template copyright. Removing the copyright without our permission is violating copyright laws (http://creativecommons.org/licenses/by/3.0/) . We regularly search for pirated sites which have stolen our copyright, using search techniques and bots and then we take legal action further.*/?>
  &nbsp;&nbsp;|&nbsp;&nbsp; Mooph theme designed by <a href="http://linesh.com/">Linesh Jose</a>
  </p>
  <?php wp_footer(); ?>
  <div class="clearboth"></div>
</div>
</div>
</body></html>